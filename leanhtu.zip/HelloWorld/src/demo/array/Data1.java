package demo.array;

//dump data
public class Data1 implements IData{

	@Override
	public void a() {
		// TODO Auto-generated method stub
		System.out.println("dump");
	}

	@Override
	public void b() {
		// TODO Auto-generated method stub
		
	}
	
	void c(){
		
	}

	
}
