package demo.array;

//ket noi database
public class Data2 implements IData{

	@Override
	public void a() {
		// TODO Auto-generated method stub
		System.out.println("connect to db");
	}

	@Override
	public void b() {
		// TODO Auto-generated method stub
		
	}
	
	public void d(){
		
	}

	

}
