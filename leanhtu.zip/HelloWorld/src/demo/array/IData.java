package demo.array;

public interface IData {
	void a();
	void b();
}
