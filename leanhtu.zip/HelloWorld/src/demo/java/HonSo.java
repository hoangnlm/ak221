package demo.java;

public class HonSo {
	int nguyen;
	PhanSo phanSo;
}
