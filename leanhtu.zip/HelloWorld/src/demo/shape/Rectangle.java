package demo.shape;

public class Rectangle extends Shape{

	@Override
	public double tinhDienTich() {
		// TODO Auto-generated method stub
		return 0;
	}
	
}
