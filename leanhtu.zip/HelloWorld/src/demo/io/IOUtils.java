package demo.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class IOUtils {
	//doc file
	public static void readBinaryTextFile(String path){  
		FileInputStream fileInputStream = null;
		try {
			//buoc 1: mo luong
			 fileInputStream = new FileInputStream(path);
		
			 //buoc 2: doc file
			 byte[] buffer = new byte[5];
			 String s = "";
			 int len= 0;
			 while( (len = fileInputStream.read(buffer)) != -1){
				 s+= new String(buffer,0,len);
			 }
			 
			 System.out.println(s);
			//buoc 3: dong luong
			fileInputStream.close();
		} catch ( IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
	}
	
	//ghi file
	public static boolean writeBinaryTextFile(String path, String content){
		
		try {
			//buoc 1: mo luong
			FileOutputStream fileOutputStream = new FileOutputStream(path);
			
			//buoc 2:ghi file
			fileOutputStream.write(content.getBytes());
			
			//buoc 3: dong luong
			fileOutputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	//copy file
	public static void copyFile(String srcPath, String desPath){
		FileInputStream fileInputStream = null;
		try {
			
		//buoc 1.1: mo luong read
			 fileInputStream = new FileInputStream(srcPath);
		//buoc 2.1: mo luong write
			FileOutputStream fileOutputStream = new FileOutputStream(desPath);
		
		//buoc 1.2: read file --> byte[]
			 byte[] buffer = new byte[5];
			 String s = "";
			 int len= 0;
			 while( (len = fileInputStream.read(buffer)) != -1){
				 s+= new String(buffer,0,len);
			 }
			 
			 System.out.println("status: JavaApp has just copied data from Input.txt to Output.txt");
		//buoc 2.2: byte[] --> write file
			 fileOutputStream.write(s.getBytes());
				
		//buoc 1.3: close read
			 fileInputStream.close();
			 
		//buoc 2.3: close write
			 fileOutputStream.close();
			
		} catch ( IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		}
}
