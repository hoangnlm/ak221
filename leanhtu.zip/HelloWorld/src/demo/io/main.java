package demo.io;

public class main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		IOUtils.writeBinaryTextFile("E:/input.txt", "Xin chao java");
//		IOUtils.readBinaryTextFile("E:/input.txt");
		
		IOUtils.copyFile("E:/Input.txt", "E:/Output.txt");

		IOUtils.readBinaryTextFile("E:/Output.txt");
	}

}
