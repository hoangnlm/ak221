package module1;

// Ket noi database
public abstract class Data2  implements IData{
	static int m = 123;
	
	@Override
	public void a() {
		// TODO Auto-generated method stub
		System.out.println("Connect database.");
	}
	
	void dd(){
		 System.out.println("method d");
	}
	

}
