package module1;

class Shape {
	double a; // canh 1
	double b; // canh 2
	double chuVi;
	double dienTich;
	int mauVien;
	int mauNen;

	Shape() {
		a = 0;
		b = 0;
		chuVi = 0;
		dienTich = 0;

		// #000000 hoac 0: mau den, #FFFFFF: mau trang, mau di tu toi sang sang.
		mauVien = 1;
		mauNen = 1;
	}

	Shape(double a, double b) {
		this.a = a;
		this.b = b;
	}

	public void XuatThongTin(){
		System.out.println("a: "+a+"\tb: "+b);
	}

	// Phuong thuc get, set
	public int getMauNen() {
		return mauNen;
	}

	public void setMauNen(int mauNen) {
		this.mauNen = mauNen;
	}

	public double getA() {
		return a;
	}

	public void setA(double a) {
		this.a = a;
	}

	public double getB() {
		return b;
	}

	public void setB(double b) {
		this.b = b;
	}

	public double getChuVi() {
		return chuVi;
	}

	public void setChuVi(double chuVi) {
		this.chuVi = chuVi;
	}

	public double getDienTich() {
		return dienTich;
	}

	public void setDienTich(double dienTich) {
		this.dienTich = dienTich;
	}

	public int getMauVien() {
		return mauVien;
	}

	public void setMauVien(int mauVien) {
		this.mauVien = mauVien;
	}

}

class Rectangle extends Shape {
	double c;
	public Rectangle(Shape shape) {
		// TODO Auto-generated constructor stub
		super(shape.a, shape.b);
		this.c = 1.11;
	}

}

class Triangle extends Shape {
	static final String TAG = "Triangle";
	double c; // canh 3
	double h; // chieu cao

	Triangle(){

	}

	Triangle(double a, double b, double c, double h){
		//		this.a=a;		//thua do da khai bao o constructor cua lop Shape
		//		this.b=b;		//~
		super(a, b);
		this.c=c;
		this.h=h;
	}

	void TinhDienTich(int anpha){

	}


	void TinhDienTich(int anpha, int beta){

	}

	//	double TinhDienThich(int anpha){		//Khong nen dung do khong biet tra ve kieu nao
	//	}

	@Override
	public void XuatThongTin(){
		super.XuatThongTin();
		//		TAG ="dfdf"; //bao loi do bien final static
		System.out.println("c: "+c+"\th: "+h);
	}

	void setH(double h){
		this.h = h;
	}
}

public class ngay0703 {
	int a;
	void a(){
		a=1;
	}

	public static void main(String[] args) {
		//		a = 1;		//Bao loi do chi truy xuat duoc static member

		Shape shape = new Shape(10,20);
		shape.XuatThongTin();
				Triangle triangle = new Triangle(5,6,7,8);
		//		shape = triangle;
		//		shape.XuatThongTin();
//		Rectangle rectangle = new Rectangle(shape);
//		rectangle.XuatThongTin();
//		System.out.println(rectangle.c);

		// Van de 1: ep kieu tu lop cha ve lop con (cu phap khong sai nhung se bi loi runtime)
		//		Triangle temp = (Triangle) shape;
		//		temp.XuatThongTin();		//Loi tu lop cha khong the ep ve lop con

		// Van de 2: ep kieu tu lop con ve lop cha
				Shape temp = triangle;
				temp.XuatThongTin();
		//		Triangle temp2 = (Triangle) temp;
		//		temp2.XuatThongTin();
		//		Rectangle temp3 = (Rectangle) temp;	//Khong duoc do khac ban chat
		//		temp.XuatThongTin();		//Xuat ca 4 thong so 5,6,10,20 khong phai 2 thong so
		//		temp.setH();		//Khong ton tai do setH danh rieng cho lop con

		//		Rectangle rectangle = new Rectangle();	
		//		TinhDienTich(triangle);		//Dung method duoc cho nhieu hinh khac nhau
		//		TinhDienTich(rectangle);	//nho su dung lop cha

		//		Triangle triangle2 =null;
		//		System.out.println(triangle2.c); 	//Bao loi 
		//		System.out.println(triangle2.TAG);
		//		System.out.println(Triangle.TAG);


	}

}
