package module1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;

public class ngay1403 {
	public static void main(String[] args) throws IOException{
//		IOUtils.writeBinaryTextFile("/Users/Hoang/Documents/Eclipse/workspace/ak221/src/input.txt", "Thu lai..");
//		IOUtils.readBinaryTextFile("/Users/Hoang/Documents/test.txt");
		
		
        // Create Reader object from StringReader constructor.
//        Reader in = new StringReader("<h1>Hello \n <b>World</b><h1>");
 
//        RemoveHTMLReader filterReader = new RemoveHTMLReader(in);
//        char[] buf = new char[1024];
//        filterReader.read(buf, 0, 3);
//        FileReader fileReader = new FileReader("/Users/Hoang/Documents/Eclipse/workspace/ak221/src/test1803/ak221/input.txt");
//        BufferedReader bufferedReader = new BufferedReader(fileReader);
//        FileWriter fileWriter = new FileWriter("/Users/Hoang/Documents/Eclipse/workspace/ak221/src/test1803/ak221/input4.txt");
        IOUtils.copyUnicodeFile("/Users/Hoang/Documents/Eclipse/workspace/ak221/src/test1803/ak221/input.txt", "/Users/Hoang/Documents/Eclipse/workspace/ak221/src/test1803/ak221/input2.txt");
		
//        IOUtils.writeTextUnicodeFile("/Users/Hoang/Documents/Eclipse/workspace/ak221/src/test1803/ak221/input3.txt", "Thử cái này \ncoi pác!");

	}
}
