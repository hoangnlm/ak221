package module1;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteStreamApp {
	public static void main(String[] args) throws IOException {
		FileInputStream inObj = null;
		FileOutputStream outObj = null;
		try {
			inObj = new FileInputStream("/Users/Hoang/Documents/input.txt");
			outObj = new FileOutputStream("/Users/Hoang/Documents/outagain.txt");
			int ch;
//			String s = "";
			StringBuilder s1 = new StringBuilder();
			while ((ch = inObj.read()) != -1) {
//				outObj.write(ch);
				System.out.println(ch);
//				s += (char)ch;
				s1.append((char)ch);
			}
			System.out.println("Thử coi bể hông?");
			System.out.println(s1);
			int te = 100;
			System.out.println((char)te);
		} finally {
				inObj.close();
				outObj.close();
		}
	}
}