package module1;

// Dump data
public class Data1 extends Data2{
	public static int TEST=123;
	
	@Override
	public void b() {
		// TODO Auto-generated method stub
		
	}
	
	void c(){
		
	}
	
	static void e(){
		System.out.println("Static method e.");
	}

	@Override
	public int d() {
		// TODO Auto-generated method stub
		return 0;
	}
}
