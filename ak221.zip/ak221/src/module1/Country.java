package module1;

import java.io.Serializable;

//Phai implement Serializable interface de chi dinh fixed order cac thuoc tinh cua object khi doc, ghi object stream. Neu khong thi cu phap dung nhung khi chay se bao loi.
public class Country implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String name;
	long population;
	double area;

	public Country(String name, long population, double area) {
		this.name = name;
		this.population = population;
		this.area = area;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPopulation() {
		return population;
	}

	public void setPopulation(long population) {
		this.population = population;
	}

	public double getArea() {
		return area;
	}

	public void setArea(double area) {
		this.area = area;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name + "/" + population + "/" + area;
	}
}
