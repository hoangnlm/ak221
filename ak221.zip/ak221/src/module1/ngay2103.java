package module1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ngay2103 {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// Khoi tao mang countries
		List<Country> countries = new ArrayList<Country>();
		Random random = new Random();
		for (int i = 0; i < 3; i++) {
			countries.add(new Country("name " + i, random.nextLong(), random.nextDouble()));
		}

		// Xuat ra ket qua tao tu buoc tren
		for (Country country : countries) {
			System.out.println(country.toString());
		}

		// ghi file tu DataStream
		String path = "/Users/Hoang/Documents/Eclipse/workspace/ak221/src/module1/test";
		// IOUtils.writeCountryByDataStream(path, countries);

		// doc file tu DataStream
		// countries = IOUtils.readCountryByDataStream(path);
		// Xuat ra ket qua tao tu buoc tren
		for (Country country : countries) {
			// System.out.println(country.toString());
		}

		// ghi file tu ObjectStream
		IOUtils.writeCountryByObjectStream(path, countries);

		// doc file tu ObjectStream
		countries = IOUtils.readCountryByObjectStream(path);
		// Xuat ra ket qua tao tu buoc tren
		for (Country country : countries) {
			System.out.println(country.toString());
		}

	}

}
