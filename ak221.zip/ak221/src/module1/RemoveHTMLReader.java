package module1;

import java.io.FilterReader;
import java.io.IOException;
import java.io.Reader;

public class RemoveHTMLReader extends FilterReader {

	// Used to remember whether we are "inside" a tag
	boolean intag = false;

	public RemoveHTMLReader(Reader in) {
		super(in);
	}

	/**
	 * This is the implementation of the no-op read() method of FilterReader. It
	 * calls in.read() to get a buffer full of characters, then strips out the
	 * HTML tags. (in is a protected field of the superclass).
	 */
	@Override
	public int read(char[] buf, int from, int len) throws IOException {
		// how many characters have been read
		int charCount = 0;

		// Loop, because we might read a bunch of characters, then strip them
		// all out, leaving us with zero characters to return.
		while (charCount == 0) {
			// Read characters
			charCount = super.read(buf, from, len);
			System.out.println("while: charCount: " + charCount);
			if (charCount == -1) {
				// Check for EOF and handle it.
				return -1;
			}
			// Loop through the characters we read, stripping out HTML tags.
			// Characters not in tags are copied over previous tags
			// Index of last non-HTML char
			int last = from;
			for (int i = from; i < from + charCount; i++) {
				// If not in an HTML tag
				if (!intag) {
					if (buf[i] == '<') {
						// Check for tag start
						intag = true;
					} else {
						// and copy the character
						buf[last++] = buf[i];
						System.out.println("last: " + last + "; from: " + from);

					}
				} else if (buf[i] == '>') {
					// check for end of tag
					intag = false;
				}
			}
			// Figure out how many characters remain
			charCount = last - from;
			System.out.println("charCount: " + charCount);
		}

		// Then return that number.
		return charCount;
	}
}
