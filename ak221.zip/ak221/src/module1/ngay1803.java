package module1;

import java.io.IOException;

import test1803.ak221.HocVien;

//BT ve nha: hoan thien bai HocVien. Up len GIT dua thay cai link GIT. Yeu cau:
// - Kiem tra du lieu nhap (validate input): ngaysinh, email phai dung dinh dang, so dien thoai dung dinh dang (chi la so, toi da 11 ky tu hoac +84:13 ky tu).
// - Doc ghi chi tren 1 file.
// - Them chuc nang: update lai thong tin hoc vien theo ma so.
// - Them chuc nang: tim kiem hoc vien trong danh sach toan truong (nhieu lop) theo ho ten, so dien thoai, email...
// - Them danh sach lop, chon lop de xem danh sach hoc vien.
// - Tim hieu List va HashMap
//Han nop: cuoi module 1.
public class ngay1803 {

	public static void main(String[] args) throws IOException {
		
	}
}
