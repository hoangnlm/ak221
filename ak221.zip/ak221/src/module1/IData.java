package module1;

public interface IData {
	int t1 = 123;
	int t2 = 233;
	void a();
	void b();

	static int c(){
		return 123;	
	}
	
	int d();
}

interface IData2 extends IData{
	void c1();
}